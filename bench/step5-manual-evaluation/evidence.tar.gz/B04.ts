export class Job {
  declare status: string;
  start(enabled: boolean) {
    if (enabled) this.status = "active";
  }
  stop() {
    this.status = "done";
  }
}
