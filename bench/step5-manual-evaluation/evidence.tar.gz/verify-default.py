import json,sys,hashlib,math
from pathlib import Path
O=Path(__file__).parent; oracle=json.loads((O/'oracle.json').read_text())
def validate(st,text):
    guard,to,stop=oracle['edits'][st]
    lines=[l for l in text.splitlines() if l.startswith('evidence kind=behavior ')]
    assert len(lines)==int(to is not None)
    if not to:return
    d=json.loads(lines[0].split(' observed_evidence=',1)[1])
    parts=d.split('. ')
    if st=='B05': assert parts.pop()=='1 owner(s) unavailable'
    assert parts.pop()=='class view covers returned members only'
    src=(O/(st+'.ts')).read_text().splitlines()
    def loc(s, condition=False):
        hits=[(n,l.index(s)) for n,l in enumerate(src,1) if s in l and (not condition or f'if ({s})' in l)]
        assert len(hits)==1
        n,i=hits[0];return f'[{n},{i},{n},{i+len(s)}]'
    expr=guard if guard=='enabled' else f'this.status === "{guard}"'
    assigned=f'this.status = "{to}"'
    start=f'start writes {assigned} in "job.ts" {loc(assigned)}, guard true {json.dumps(expr)} {loc(expr,True)}, candidate prior '+('unknown' if guard=='enabled' else json.dumps(guard))
    expected=[start]
    if stop:
        a='this.status = "done"';expected.append(f'stop writes {a} in "job.ts" {loc(a)}, candidate prior unknown')
    assert sorted(parts)==sorted(expected),(parts,expected)
if __name__=='__main__':
    for st in oracle['edits']:validate(st,(O/(st+'-packet-full.txt')).read_text())
    corrupt=(O/'V0-packet-full.txt').read_text().replace('candidate prior unknown','candidate prior done')
    try:validate('V0',corrupt)
    except AssertionError:print('PASS: corrupted prior rejected')
    else:raise AssertionError('negative control survived')
    print('PASS: all seven default responses compared to source and oracle')
