import subprocess,os,time,json,sys,pathlib
O=pathlib.Path('/private/tmp/ix-step5-review.cnumUe'); P=pathlib.Path('/private/tmp/ix-step5-project.WXAFyQ'); PUBLIC=pathlib.Path('/private/tmp/ix-eval-tools.KbyEgJ'); NODE='/opt/homebrew/bin/node'; IX='/Users/sambraude/Ix/Ix/ix-cli/dist/cli/main.js'
CODEX='/Users/sambraude/.local/bin/codex'
MODEL='gpt-6.2-sol'
question="Which methods can write this class's state field? For each site give the assigned value, observed controlling branch, candidate prior if supported, and source citation. What can you conclude about ordering, reachability and completeness?"
def run(label,arm,stage='V0'):
    args=[CODEX,'exec','--ephemeral','--ignore-user-config','--sandbox','read-only','--model',MODEL,'--json']
    for name in ['apps','hooks','memories','shell_tool','multi_agent','browser_use','unified_exec']:
        args.extend(['--disable',name])
    def cfg(key,val):
        # JSON strings and homogeneous arrays are also TOML
        args.extend(['-c',key+'='+json.dumps(val)])
    cfg('model_reasoning_effort','low');cfg('web_search','disabled');cfg('project_doc_max_bytes',0)
    def server(name,entry,allowed,cwd):
        cfg('mcp_servers.'+name+'.command',NODE);cfg('mcp_servers.'+name+'.args',entry);cfg('mcp_servers.'+name+'.enabled_tools',allowed);cfg('mcp_servers.'+name+'.cwd',str(cwd))
    if arm in ('demo','live'):
        server('ix',[IX,'mcp'],['ix_context'],P)
        for k,v in [('IX_HOME','/private/tmp/ix-step5-home.OTN0iV'),('IX_ENDPOINT','http://127.0.0.1:8315'),('IX_NO_UPDATE_CHECK','1')]:cfg('mcp_servers.ix.env.'+k,v)
    if arm!='demo':
        server('source',[str(PUBLIC/'source.mjs'),str(P/'job.ts')],['read_job_source'],P)
    instr="Use only the supplied material and read-only evaluation tools for this one-file TypeScript repository. Do not look for previous trials, external files or instructions. Cite ranges when available. If evidence is insufficient, state what remains unknown. Answer concisely."
    if arm in ('demo','live'):
        instr+=" First call ix_context exactly once with only target Job, with no other arguments."
    if arm=='demo': instr+=" Use only that default response. Do not open source."
    if arm in ('full','ablated'):
        text=(O/(stage+'-packet-'+arm+'.txt')).read_text()
        instr+="\nRepository context returned for Job:\n"+text
    prompt=instr+'\n'+question
    # A second OS boundary protects private evaluation material even if the tool catalog changes.
    blocks=[str(O),'/Users/sambraude/.codex/sessions','/Users/sambraude/.codex/archived_sessions','/private/tmp/ix-step41.KaRra7','/private/tmp/ix-step4.uhK1Kx']
    profile='(version 1)(allow default)'+''.join('(deny file-read* (subpath '+json.dumps(k)+'))' for k in blocks)
    argv=['/usr/bin/sandbox-exec','-p',profile,*args,'-']
    dest=O/'runs';dest.mkdir(exist_ok=True)
    start=time.monotonic()
    with (dest/(label+'.jsonl')).open('w') as out,(dest/(label+'.err')).open('w') as err:
        try:
            cp=subprocess.run(argv,cwd=P,input=prompt,text=True,stdout=out,stderr=err,timeout=210);rc=cp.returncode
        except subprocess.TimeoutExpired:rc=124
    meta={'label':label,'stage':stage,'arm':arm,'rc':rc,'elapsed_s':round(time.monotonic()-start,3),'model':MODEL,'reasoning':'low','argv':args,'prompt':prompt}
    (dest/(label+'.meta.json')).write_text(json.dumps(meta,indent=2))
    return rc
if __name__=='__main__':sys.exit(run(*sys.argv[1:]))
