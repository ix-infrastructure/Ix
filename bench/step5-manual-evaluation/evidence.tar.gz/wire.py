import json,sys,urllib.request,hashlib
from pathlib import Path
O=Path(__file__).parent;P=Path('/private/tmp/ix-step5-project.WXAFyQ')
st=sys.argv[1]
src=(O/(st+'.ts')).read_bytes();assert src==(P/'job.ts').read_bytes()
result={}
b=json.loads((O/(st+'-audit.json')).read_text())['res']['structuredContent']
for node in b['entities']:
 if node['name'] not in ('start','stop'):continue
 with urllib.request.urlopen('http://127.0.0.1:8315/v1/entity/'+node['id'],timeout=10) as r:
    d=json.load(r)
 n=d['node'];assert n['id']==node['id'] and n['kind']=='method' and n['name']==node['name']
 assert ('behavior_v1' in n['attrs'])==(st=='B07')
 assert n['provenance']['sourceHash']==hashlib.sha256(src).hexdigest()
 result[node['name']]=d
assert len(result)==2 and src==(P/'job.ts').read_bytes()
(O/(st+'-entities-wire.json')).write_text(json.dumps(result,indent=2))
print(st,'verified both method IDs, source hashes and attribute presence')
