import fs from 'node:fs';
import {McpServer} from '@modelcontextprotocol/sdk/server/mcp.js';
import {StdioServerTransport} from '@modelcontextprotocol/sdk/server/stdio.js';
const source=process.argv[2];
const server=new McpServer({name:'fixture-reader',version:'1'});
server.registerTool('read_job_source',{description:'Read the complete current job.ts with one-based line numbers.',inputSchema:{},annotations:{readOnlyHint:true}},async()=>({content:[{type:'text',text:fs.readFileSync(source,'utf8').trimEnd().split('\n').map((line,i)=>(i+1)+' | '+line).join('\n')}]}));
await server.connect(new StdioServerTransport());
