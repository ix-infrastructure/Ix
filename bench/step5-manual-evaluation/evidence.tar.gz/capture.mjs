import fs from 'node:fs';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
const [out,stage,dir,home,main]=process.argv.slice(2);
const env={PATH:process.env.PATH,HOME:process.env.HOME,IX_HOME:home,IX_ENDPOINT:'http://127.0.0.1:8315',IX_NO_UPDATE_CHECK:'1'};
const s=new StdioClientTransport({command:process.execPath,args:[main,'mcp'],env,cwd:dir,stderr:'pipe'});const c=new Client({name:'step-5-operator',version:'1'});
let stderr='';s.stderr?.on('data',d=>stderr+=d);
try{await c.connect(s);for(const [kind,args] of [['default',{target:'Job'}],['audit',{target:'Job',structured:true,max_chars:24000}],['start',{target:'Job.start',structured:true,max_chars:24000}],['stop',{target:'Job.stop',structured:true,max_chars:24000}]]){
const req={name:'ix_context',arguments:args},t=performance.now(),res=await c.callTool(req);fs.writeFileSync(out+'/'+stage+'-'+kind+'.json',JSON.stringify({req,ms:performance.now()-t,res},null,2));
if(res.isError)throw new Error(JSON.stringify(res.content));
if(kind==='default'){const text=res.content.map(x=>x.text).join('\n');fs.writeFileSync(out+'/'+stage+'-packet-full.txt',text);fs.writeFileSync(out+'/'+stage+'-packet-ablated.txt',text.split('\n').filter(l=>!/^evidence\s.*\bkind=behavior\b/.test(l)).join('\n'));}}
}finally{await c.close();fs.writeFileSync(out+'/'+stage+'-server.log',stderr)}
