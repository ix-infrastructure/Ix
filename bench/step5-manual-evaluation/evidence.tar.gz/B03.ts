export class Job {
  declare status: string;
  start() {
    if (this.status === "paused") this.status = "active";
  }
  stop() {
    this.status = "done";
  }
}
