export class Job {
  declare status: string;
  start(enabled: boolean) {
    if (enabled) return;
  }
  stop() {
    return;
  }
}
