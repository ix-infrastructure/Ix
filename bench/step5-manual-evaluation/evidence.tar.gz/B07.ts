export class Job {
  declare status: string;
  start() {
    if (this.status === "queued") this.status = "running";
  }
  stop() {
    this.status = "done";
  }
}
