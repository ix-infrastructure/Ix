export class Job {
  declare status: string;
  start() {
    if (this.status === "paused") this.status = "running";
  }
  stop() {
    this.status = "done";
  }
}
