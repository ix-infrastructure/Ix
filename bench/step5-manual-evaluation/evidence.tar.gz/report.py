import json,math,csv,statistics
from pathlib import Path
O=Path(__file__).parent
def j(p):return json.loads((O/p).read_text())
d=j('outcomes.json');cards=list(csv.DictReader((O/'scorecards.csv').open()));pairs=list(csv.DictReader((O/'pairs.csv').open()))
aud=[json.loads(l) for l in (O/'audit.jsonl').read_text().splitlines()]
usage=next(e['usage'] for e in map(json.loads,(O/'runs/demonstration.jsonl').read_text().splitlines()) if e['type']=='turn.completed')
report=['# Step 5 controlled manual MVP evaluation','', (O/'interpretation.txt').read_text().strip(),'','## What the real default call returned','',
'After the development build ran ordinary `map .`, Codex called `ix_context({"target":"Job"})` once and opened zero source files. The raw MCP text includes this evidence record.','',
'```text',next(l for l in (O/'V0-packet-full.txt').read_text().splitlines() if 'kind=behavior' in l),'```','',
'Both methods resolved under class `'+aud[0]['classId']+'` and one instance-field slot `'+next(x['behavior'] for x in j('V0-audit.json')['res']['structuredContent']['evidence'] if x.get('behavior'))['slots'][0]['slotId']+'`. The write and guard spans use one-based lines and zero-based UTF-16 columns with an exclusive end. The guard constrains the observed branch. The response supplies a candidate prior and the assignment destination. It establishes neither an initial/terminal state nor an ordering between calls. The class projection covers only returned members.','',
f"The demonstration took {j('runs/demonstration.meta.json')['elapsed_s']:.2f} s. The model service reported {usage['input_tokens']:,} input tokens, including {usage['cached_input_tokens']:,} cached, and {usage['output_tokens']} output tokens. Its default tool text contained {aud[0]['fullBytes']} bytes. See runs/demonstration.jsonl for the complete argument, return and answer.",'','## Source and lifecycle checks','',
'| Case | Oracle observation | Result | Mapped writes | Default bytes | Behavioral row estimated tokens |',
'|---|---|---|---:|---:|---:|']
names={'V0':['B-01','One slot shared across start and stop. Guard, candidate prior and all source slices match.'],'B02':['B-02','Only the guard and inferred prior change to paused. The stop write ID survives.'],'B03':['B-03','Destination changes to active. The prior remains paused.'],'B04':['B-04','The enabled guard remains observed. Both candidate priors are unknown.'],'B05':['B-05','The done write is retired. The stop method ID survives.'],'B06':['B-06','All current writes disappear. The class and both original method IDs still resolve.'],'B07':['B-07','Original sites, IDs, source hash, spans, guards and priors restored in the original workspace.']}
for a in aud:
    case,desc=names[a['stage']];report.append(f"| {case} | {desc} | {'FAIL' if a.get('error') else 'PASS'} | {len(a.get('sites',{}))} | {a.get('fullBytes','?')} | {math.ceil((a.get('fullChars',0)-a.get('cutChars',0))/2.14)} |")
report+=['','Full class and both individually resolved method projections were checked at every revision. The default-text checker independently reconstructed expected assignments, guards, priors and citation slices from each fixture and the pre-map labels. A negative control replaced the unknown prior for stop and the checker rejected it. See audit.jsonl, verify-default.log and each *-audit.json.','',
'## Matched Codex trials','',
'Three pairs per source revision and comparison yielded 36 separately launched sessions plus the demonstration. Each arm has nine runs. Medians below are calculated across sessions within each arm. Model tokens are telemetry reported by Codex. Visible context is a separate estimate over supplied packet text and actual tool outputs.','',
'| Arm | Score /10 | Source reads, total | All tools, total | Visible context, median tokens | Model input, median | Cached input, median | Output, median | Wall, median s |',
'|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for k in ['source','live','ablated','full']:
    a=d[k];m=a['medians'];t=a['totals']
    report.append(f"| {k} | {m['score']} | {t['source_reads']} | {t['tools']} | {m['context_est_tokens']} | {m['input_tokens']:,} | {m['cached_input_tokens']:,} | {m['output_tokens']} | {m['elapsed_s']:.2f} |")
report+=['','Practical trials compare source-only with a live default call plus optional source. Ablation trials compare replayed packets with exactly one behavioral line removed or retained, with identical access to the source reader. Columns below are medians of within-pair differences, treatment minus control.','',
'| Comparison | Wins/ties/losses on score | Score Δ | Source reads Δ | All tools Δ | Visible tokens Δ | Actual input Δ | Output Δ | Seconds Δ |','|---|---|---:|---:|---:|---:|---:|---:|---:|']
for k in ['live minus source','full minus ablated']:
    a=d[k];m=a['medians'];report.append(f"| {k} | {'/'.join(map(str,a['wins_ties_losses']))} | {m['score']:+} | {m['source_reads']:+} | {m['tools']:+} | {m['context_est_tokens']:+} | {m['input_tokens']:+,} | {m['output_tokens']:+} | {m['elapsed_s']:+.2f} |")
report+=['','| Revision | Comparison | Per-pair score differences | Per-pair source-read differences |','|---|---|---|---|']
for st in ('V0','B04','B06'):
    for cmp in ('live minus source','full minus ablated'):
        z=[r for r in pairs if r['stage']==st and r['comparison']==cmp]
        report.append(f"| {st} | {cmp} | {', '.join(r['score'] for r in z)} | {', '.join(r['source_reads'] for r in z)} |")
report+=['','## Errors, limits and readiness','',(O/'notes.txt').read_text().strip(),'',
'Per-answer scores, comments and usage are in scorecards.csv. Pair differences are in pairs.csv. PROTOCOL.md describes isolation and reproduction. The evidence archive contains the unmodified model event streams, actual prompts, operator captures and per-revision source snapshots. Linux prerequisites for the deferred production benchmark are in TRACK-A-LINUX.md.']
(O/'REPORT.md').write_text('\n'.join(report)+'\n')
