import json,random,statistics,hashlib,csv,sys,re,math
from pathlib import Path
from collections import Counter
from itertools import groupby
O=Path(__file__).parent; RUNS=O/'runs'
def getfile(p):return json.loads(p.read_text())
stages=('V0','B04','B06'); arms=('source','live','ablated','full')
labels=[f'{st}-{i}-{a}' for st in stages for i in (1,2,3) for a in arms]
random.Random(59_119).shuffle(labels);lookup={f'R{i:02d}':lab for i,lab in enumerate(labels,1)}
def entries(label):
    return [json.loads(line) for line in (RUNS/(label+'.jsonl')).read_text().splitlines() if line.strip()]
def answer(es):
    return [e['item']['text'] for e in es if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message'][-1]
def length(s):return len(s.encode('utf-16-le'))//2
def blind(st):
    for blind_id,label in lookup.items():
        if not label.startswith(st+'-') or not (RUNS/(label+'.meta.json')).exists():continue
        print(blind_id,answer(entries(label))+'\n')
def stats():
    scores=getfile(O/'blind-scores.json');rows=[]
    for bid,label in lookup.items():
        st,n,arm=label.split('-');meta=getfile(RUNS/(label+'.meta.json'));es=entries(label)
        ts=[e['item'] for e in es if e.get('type')=='item.completed' and e['item']['type'] not in ['agent_message','reasoning']]
        assert all(t['type']=='mcp_tool_call' and t['tool'] in ('ix_context','read_job_source') for t in ts),ts
        calls=Counter(t['tool'] for t in ts)
        full=(O/(st+'-packet-full.txt')).read_text();cut=(O/(st+'-packet-ablated.txt')).read_text()
        result_text=[]
        for t in ts:
            assert t['status']=='completed' and not t.get('error') and not t['result'].get('isError'),t
            txt=t['result']['content'][0]['text'];result_text.append(txt)
            if t['tool']=='ix_context':
                assert t['arguments']=={'target':'Job'} and txt==full
            if t['tool']=='read_job_source':
                truth=(O/(st+'.ts')).read_text().rstrip('\n').splitlines()
                assert txt=='\n'.join(f'{i} | {s}' for i,s in enumerate(truth,1))
        assert calls['ix_context']==int(arm=='live')
        if arm=='live':assert ts[0]['tool']=='ix_context'
        events=[e for e in es if e['type']=='turn.completed'];assert len(events)==1 and meta['rc']==0
        u=events[0]['usage'];packet=full if arm=='full' else cut if arm=='ablated' else ''
        srctexts=[t['result']['content'][0]['text'] for t in ts if t['tool']=='read_job_source']
        grade=scores[bid];assert len(grade['points'])==6 and all(0<=g<=w for g,w in zip(grade['points'],[2,2,2,2,1,1]))
        rows.append({'blind_id':bid,'label':label,'stage':st,'pair':int(n),'arm':arm,'score':sum(grade['points']),**dict(zip(['owners','destinations','guards','priors','citations','limitations'],grade['points'])),
            'exact_write_guard_spans':grade.get('exact_spans','N/A'),'incorrect_claims':grade.get('incorrect',0),'critical_errors':grade.get('critical',0),'scoring_note':grade.get('note',''),
            'tools':len(ts),'source_reads':len(srctexts),'ix_calls':calls['ix_context'],
            'source_result_bytes':sum(len(s.encode()) for s in srctexts),'evidence_packet_bytes':len(packet.encode()),
            'context_est_tokens':math.ceil((length(packet)+sum(map(length,result_text)))/2.14),
            'elapsed_s':meta['elapsed_s'],**u,'cold_input_tokens':u['input_tokens']-u['cached_input_tokens']})
    def writecsv(name,rows):
        with (O/name).open('w') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    writecsv('scorecards.csv',sorted(rows,key=lambda r:(stages.index(r['stage']),r['pair'],r['arm'])))
    metrics=['score','incorrect_claims','critical_errors','source_reads','tools','context_est_tokens','input_tokens','cached_input_tokens','cold_input_tokens','output_tokens','elapsed_s']
    summary={}
    for a in arms:
        g=[r for r in rows if r['arm']==a]
        summary[a]={'N':len(g),'medians':{k:statistics.median(r[k] for r in g) for k in metrics},'totals':{k:sum(r[k] for r in g) for k in metrics}}
    pairs=[]
    for x,y in [('source','live'),('ablated','full')]:
        for st in stages:
            for i in (1,2,3):
                a,b=[next(r for r in rows if r['arm']==m and r['stage']==st and r['pair']==i) for m in (x,y)]
                pairs.append({'comparison':y+' minus '+x,'stage':st,'pair':i,**{k:round(b[k]-a[k],3) for k in metrics}})
    writecsv('pairs.csv',pairs)
    for name,group in groupby(pairs,key=lambda x:x['comparison']):
        g=list(group);summary[name]={'medians':{k:statistics.median(r[k] for r in g) for k in metrics},
            'wins_ties_losses':[sum(op(r['score']) for r in g) for op in [lambda v:v>0,lambda v:v==0,lambda v:v<0]]}
    (O/'outcomes.json').write_text(json.dumps(summary,indent=2))
if __name__=='__main__':
    if sys.argv[1]=='blind':blind(sys.argv[2])
    else:stats()
