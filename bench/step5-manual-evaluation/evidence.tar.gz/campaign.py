import hashlib, json, random, subprocess, sys, time
from pathlib import Path
from trial import O,P,PUBLIC,NODE,IX,run
from collections import Counter
home='/private/tmp/ix-step5-home.OTN0iV'
import os
env={**os.environ,'IX_HOME':home,'IX_ENDPOINT':'http://127.0.0.1:8315','IX_NO_UPDATE_CHECK':'1'}
oracle=json.loads((O/'oracle.json').read_text())
edits={'B02':[('"queued"','"paused"')],'B03':[('"running"','"active"')],'B04':[('start()','start(enabled: boolean)'),('this.status === "paused"','enabled')],'B05':[('this.status = "done";','return;')],'B06':[('if (enabled) this.status = "active";','if (enabled) return;')]}
original=(O/'v0.ts').read_text(); stages=list(oracle['edits'])
def audit(st):
    def res(typ):return json.loads((O/(st+'-'+typ+'.json')).read_text())['res']
    def row(bundle):return [x['behavior'] for x in bundle['evidence'] if x['kind']=='behavior']
    def sliceof(src,s):
        a,b,c,d=s; assert a==c; return src.splitlines()[a-1].encode('utf-16-le')[2*b:2*d].decode('utf-16-le')
    truth,destination,stop=oracle['edits'][st]
    src=(O/(st+'.ts')).read_text(); content=res('default')['content'][0]['text']
    full=(O/(st+'-packet-full.txt')).read_text(); cut=(O/(st+'-packet-ablated.txt')).read_text()
    b=res('audit')['structuredContent']; vs=row(b); want=[k for k,v in [('start',destination),('stop',stop)] if v]
    base=json.loads((O/'V0-audit.json').read_text())['res']['structuredContent']
    ids={k['name']:k['id'] for k in base['entities']}; assert ids=={k['name']:k['id'] for k in b['entities']}
    assert 'structuredContent' not in res('default') and not res('default').get('isError') and content==full
    assert [l for l in full.splitlines() if 'kind=behavior ' not in l]==cut.splitlines()
    assert len(full.splitlines())-len(cut.splitlines())==bool(want)
    assert len(vs)==bool(want)
    sites={}
    if want:
        view=vs[0]; assert view['scope']=='returned-members' and all(view[k]==0 for k in ['omittedWrites','omittedMembers']) and view['unavailableMembers']==int(st=='B05')
        slot,=view['slots']; assert slot['slotKind']=='instanceField' and slot['slotName']=='status'
        assert slot['slotId']==row(base)[0]['slots'][0]['slotId']
        sites={s['ownerName']:s for s in slot['sites']}; assert len(slot['sites'])==len(want) and set(sites)==set(want)
        assert 'class view covers returned members only' in full
    for method in ('start','stop'):
        bundle=res(method)['structuredContent'];assert bundle['target']['id']==ids[method];v=row(bundle)
        assert bool(v)==(method in want)
        if not v:continue
        w=sites[method];assert v[0]['slots'][0]['sites']==[w] and w['ownerId']==ids[method]
        val=destination if method=='start' else 'done';prior=truth if method=='start' and truth!='enabled' else None
        assert w['observed']['to']=={'kind':'string','value':val} and w['source']['uri']=='job.ts'
        assert w['extraction']['coverage']=='complete' and w['source']['hash']==hashlib.sha256(src.encode()).hexdigest()
        assert sliceof(src,w['observed']['assignment'])==f'this.status = "{val}"'
        assert w['inferred']['from']==({'kind':'string','value':prior} if prior else 'unknown')
        guards=w['observed']['guards'];assert len(guards)==int(method=='start')
        if guards:
            g,=guards; expr='enabled' if truth=='enabled' else f'this.status === "{truth}"'
            assert g['expression']==expr and g['arm']=='then' and g['sameSlot']==(truth!='enabled') and sliceof(src,g['span'])==expr
        desc=next(l for l in full.splitlines() if 'kind=behavior ' in l)
        assert method+' writes this.status' in desc and json.dumps(w['observed']['assignment'],separators=(',',':')) in desc
    baseSites={x['ownerName']:x for x in row(base)[0]['slots'][0]['sites']}
    if stop:assert sites['stop']['id']==baseSites['stop']['id']
    if st in ('V0','B07'):
        assert sites==baseSites
        assert sites['start']['observed']['assignment']==oracle['initialSpans']['start']
        assert sites['start']['observed']['guards'][0]['span']==oracle['initialSpans']['guard']
        assert sites['stop']['observed']['assignment']==oracle['initialSpans']['stop']
    if st in ('B02','B03','B04','B05'):assert 'queued' not in full
    if st in ('B03','B04','B05'):assert 'running' not in full
    if st in ('B04','B05'):assert 'paused' not in full
    if st=='B05':assert 'stop writes' not in full and 'done' not in full
    if st=='B06':assert all(s not in full for s in ('writes this.status','candidate prior','queued','running','done','active','paused'))
    return {'stage':st,'classId':ids['Job'],'sourceHash':hashlib.sha256(src.encode()).hexdigest(),'sites':{m:w['id'] for m,w in sites.items()},'fullChars':len(full),'fullBytes':len(full.encode()),'cutChars':len(cut)}
def emit(events,obj):
    with (O/events).open('a') as f:f.write(json.dumps(obj)+'\n')
    print(json.dumps(obj),flush=True)
def main():
    for n,st in enumerate(stages):
        if st!='V0':
            src=(P/'job.ts').read_text()
            if st=='B07':src=original
            else:
                for a,b in edits[st]:
                    assert src.count(a)==1;src=src.replace(a,b)
            (P/'job.ts').write_text(src)
            with (O/(st+'-map.log')).open('w') as out:subprocess.run([NODE,IX,'map','.'],cwd=P,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
            subprocess.run([NODE,str(O/'capture.mjs'),str(O),st,str(P),home,IX],check=True,env=env)
        (O/(st+'.ts')).write_text((P/'job.ts').read_text())
        try: result=audit(st)
        except (AssertionError,KeyError,ValueError) as e:
            import traceback
            result={'stage':st,'error':traceback.format_exc()}
        emit('audit.jsonl',result)
        if st in ('V0','B04','B06'):
            for pair in range(3):
                for group,arms in [('practical',['source','live']),('ablation',['ablated','full'])]:
                    phase=['V0','B04','B06'].index(st)
                    if (pair+phase+int(group=='ablation'))%2:arms.reverse()
                    for arm in arms:
                        label=f'{st}-{pair+1}-{arm}';rc=run(label,arm,st);emit('progress.jsonl',{'label':label,'rc':rc})
                        if rc!=0:raise RuntimeError('Inspect infrastructure failure '+label)
if __name__=='__main__':main()
